var process = function() {
	"use strict";
	return {
	}
}();