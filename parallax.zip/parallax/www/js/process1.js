var w = 1280, h = 600;
var game = new Phaser.Game(w, h, Phaser.CANVAS, '');
var Parallax = function(){

}