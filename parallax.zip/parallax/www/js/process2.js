var bg1, bg2, bg3;
Parallax.prototype = {
	preload:function(){
		game.load.image("bg1", "img/mount1.png");
		game.load.image("bg2", "img/mount2.png");
		game.load.image("bg3", "img/mount3.png");
		game.load.spritesheet("char", "img/natnat.png", 47,47)
	},
	create:function(){
		game.stage.backgroundColor = "#deeppink";

		bg1 = game.add.tileSprite(0,
			(game.height - game.cache.getImage("bg1").height)+100,
			game.width,
			game.cache.getImage("bg1").height,
			'bg1');

		bg2 = game.add.tileSprite(0,
			(game.height - game.cache.getImage("bg2").height)+100,
			game.width,
			game.cache.getImage("bg2").height,
			'bg2');

		bg3 = game.add.tileSprite(0,
			(game.height - game.cache.getImage("bg3").height)+100,
			game.width,
			game.cache.getImage("bg3").height,
			'bg3');

	},
	update:function(){
	
			bg1.tilePosition.x +=0.3;
			bg2.tilePosition.x +=0.6;
			bg3.tilePosition.x +=0.9;

	}
}
game.state.add("gameplay", Parallax, true);